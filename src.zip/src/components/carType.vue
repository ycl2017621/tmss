<template lang=''>
  <div id="carType">
    车型
    <tab-bar></tab-bar>
  </div>
</template>

<script>
  import tabBar from '@/components/tabBar'
  export default {
    name: 'carType',
    components: {
      tabBar
    }
  }
</script>
