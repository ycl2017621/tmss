<template>
    <div id="home">首页
        <tab-bar></tab-bar>
    </div>
</template>

<script>
    import tabBar from '@/components/tabBar'
    export default {
        name: 'home',
        data() {
            return {
    
            }
        },
        components: {
            tabBar
        }
    }
</script>
<style>

</style>

