<template>
  <div id="mine">我的
    <tab-bar></tab-bar>
  </div>
</template>

<script>
  import tabBar from '@/components/tabBar'
  export default {
    name: 'carType',
    components: {
      tabBar
    }
  }
</script>