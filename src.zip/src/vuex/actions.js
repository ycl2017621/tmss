'use strict'
export default{
    
}