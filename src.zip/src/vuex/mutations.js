'use strict'
export default{
    updateTab(state,currTab){
        state.currTab = currTab
    }
}